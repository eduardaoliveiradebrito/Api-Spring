package br.com.duda;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestDudaConsumerApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestDudaConsumerApplication.class, args);
	}

}
